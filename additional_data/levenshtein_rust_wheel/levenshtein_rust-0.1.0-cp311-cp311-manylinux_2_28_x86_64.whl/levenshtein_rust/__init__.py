from .levenshtein_rust import *

__doc__ = levenshtein_rust.__doc__
if hasattr(levenshtein_rust, "__all__"):
    __all__ = levenshtein_rust.__all__